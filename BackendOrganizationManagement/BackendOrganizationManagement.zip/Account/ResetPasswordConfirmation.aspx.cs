﻿using System.Web.UI;

namespace BackendOrganizationManagement.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}