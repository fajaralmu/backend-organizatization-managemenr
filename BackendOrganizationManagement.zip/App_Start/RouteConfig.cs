using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Routing; 

namespace BackendOrganizationManagement
{
    public static class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
           
        }
    }
}
