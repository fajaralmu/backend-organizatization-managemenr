﻿ 
namespace BackendOrganizationManagement
{
    public partial class Startup
    {
    }
}
